import { useState } from "react";
import Login from "./components/Login";
import Dashboard from "./components/Dashboard";

function App() {
  const [auth, setAuth] = useState(
    !!localStorage.getItem("token")
  );

  return auth ? <Dashboard /> : <Login setAuth={setAuth} />;
}

export default App;