 const fetchData = async () => {
  try {
    const token = localStorage.getItem("token");

    const res = await axios.get("http://127.0.0.1:8000/history/", {
      headers: {
        Authorization: `Bearer ${token}`, // ✅ MUST
      },
    });

    setTransactions(res.data);
  } catch (error) {
    console.log(error);

    // 🚨 if token invalid → logout
    if (error.response?.status === 401) {
      alert("Session expired, login again");
      localStorage.removeItem("token");
      window.location.reload();
    }
  }
};