import { useState } from "react";
import axios from "axios";

export default function TransactionForm({ refresh }) {
  const [amount, setAmount] = useState("");
  const [result, setResult] = useState("");

  const submitTransaction = async () => {
    try {
      const res = await axios.post(
        "http://127.0.0.1:8000/transaction/",
        {
          amount,
          location: "India",
          device: "Mobile",
        },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );

      // ✅ set result from backend
      setResult(res.data.status);

      // refresh dashboard
      refresh();

      // clear input
      setAmount("");
    } catch (error) {
      console.log(error);
      alert("Something went wrong ❌");
    }
  };

  return (
    <div className="bg-white p-4 rounded shadow mb-4">
      <h2 className="font-bold mb-2">Add Transaction</h2>

      <input
        className="border p-2 mr-2 rounded"
        type="number"
        placeholder="Enter Amount"
        value={amount}
        onChange={(e) => setAmount(e.target.value)}
      />

      <button
        onClick={submitTransaction}
        className="bg-blue-500 text-white px-4 py-2 rounded"
      >
        Submit
      </button>

      {/* ✅ RESULT DISPLAY */}
      {result && (
        <div className="mt-4 text-lg font-bold">
          Result:{" "}
          <span
            className={
              result === "Fraud" ? "text-red-500" : "text-green-500"
            }
          >
            {result === "Fraud" ? "❌ Fraud" : "✅ Safe"}
          </span>
        </div>
      )}
    </div>
  );
}




































// import { useState } from "react";
// import axios from "axios";

// export default function TransactionForm({ refresh }) {
//   const [amount, setAmount] = useState("");

//   const submitTransaction = async () => {
//     await axios.post(
//       "http://127.0.0.1:8000/transaction/",
//       {
//         amount,
//         location: "India",
//         device: "Mobile",
//       },
//       {
//         headers: {
//           Authorization: `Bearer ${localStorage.getItem("token")}`,
//         },
//       }
//     );

//     setAmount("");
//     refresh();
//   };

//   return (
//     <div className="bg-white p-4 rounded shadow mb-4">
//       <input
//         className="border p-2 mr-2"
//         placeholder="Enter Amount"
//         value={amount}
//         onChange={(e) => setAmount(e.target.value)}
//       />

//       <button
//         onClick={submitTransaction}
//         className="bg-green-500 text-white px-4 py-2 rounded"
//       >
//         Submit
//       </button>
//     </div>
//   );
// }